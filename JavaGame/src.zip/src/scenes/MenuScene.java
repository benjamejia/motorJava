package scenes;

import java.awt.Graphics;
import java.awt.event.KeyEvent;

import core.KeyHandler;

public class MenuScene extends Scene{

    SceneManager sceneManager;
    KeyHandler keyHandler;
    private int sizeWidth;
    private int sizeHeight;

    public MenuScene(SceneManager sm, KeyHandler kh, int sizeWidth, int sizeHeight){
        this.sceneManager = sm;
        this.keyHandler = kh;
        this.sizeWidth = sizeWidth;
        this.sizeHeight = sizeHeight;
    }

    @Override
    public void init() {
        System.out.println("Menu funcionando");
    }

    @Override
    public void update() {
        if(keyHandler.getTeclaPresionada() == KeyEvent.VK_ESCAPE){
            sceneManager.deleteCurrentScene();
        }
    }

    @Override
    public void draw(Graphics g) {
        g.fillRect(100, 100, sizeWidth / 2, sizeHeight / 2);
        g.drawString("Menu pausa", sizeWidth / 2, sizeHeight / 2);
        g.dispose();
    }

    @Override
    public void dispose() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'dispose'");
    }

}
